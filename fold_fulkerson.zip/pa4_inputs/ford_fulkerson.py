# ford_fulkerson.py


import sys
from collections import deque

############################

# DO NOT CHANGE THIS PART!!

############################

def readInput(input_file):
    with open(input_file, 'r') as f:
        raw = [[int(x) for x in s.split(',')] for s in f.read().splitlines()]
        # number of vertices
        N = raw[0][0]
        # number of edges
        m =  raw[1][0]
        # source
        s = raw[2][0]
        # sink
        t = raw[3][0]
        # intervals, with name of interval as an int
        directed_edges = raw[4:]

        return N, m, s, t, directed_edges
    

def writeOutput(max_flow, output_file):
    with open(output_file, 'w') as f:
        for edge in max_flow:
            f.write(str(edge[0]) + ',' + str(edge[1]) + ',' + str(edge[2]) + '\n')


def Run(input_file, output_file):
    N, m, s, t, directed_edges = readInput(input_file)
    max_flow = ford_fulkerson(N, m, s, t, directed_edges)
    writeOutput(max_flow, output_file)


############################

def sort(N, m, s, t, directed_edges):
     edges = directed_edges.copy()
     result = {}
     while(edges):
          edge = edges.pop(0)
          if s not in result and edge[0] == s:
               result.update({edge[0]:[edge[1]]})
          elif edge[0] in result:
               result[edge[0]].append(edge[1])
          else:
               result.update({edge[0]:[edge[1]]})
     return result

def BFS(N, s, t, directed_edges):
     Q = []
     for e in directed_edges:
          Q.append(e)
     conn= set([s])
     forwardedges = []
     l = len(conn)
     while l < N:
          e = Q.pop(0)
          if e[2] == e[3]:
               N -= 1
          if e[0] in conn and e[1] not in conn and e[2] != e[3]:
               conn.add(e[1])
               forwardedges += [e]
          else:
               Q.append(e)
          l = len(conn)
     backwardedges = Q
     if(t not in conn):
          for i in range(len(backwardedges)):
               if backwardedges[i][0] in conn and backwardedges[i][1] == t and backwardedges[i][2] != backwardedges[i][3]:
                    #print("find the edge", backwardedges[i])
                    forwardedges += [backwardedges[i]]
                    backwardedges.pop(i)
                    break
     return forwardedges, backwardedges
########################################
def bottle_neck(s, t, edges):
     #a,b = BFS(len(edges)*2-2 , s, edges)
     neck = 10000000
     for e in edges:
          if(e[2]-e[3])<neck:
               neck = e[2]-e[3]
     return neck
############################
def find_path(s,t,forward):
     Q = []
     if len(forward)==0:
          return -1
     for e in forward:
          Q.append(e)
     conn= set([t])
     forwardedges = []
     checker = Q.pop(0)
     Q.append(checker)
     counter = len(forward)
     while Q:
          #print(counter)
          e = Q.pop(0)
          if e[1] in conn and e[0] not in conn and e[2] != e[3]:
               conn.add(e[0])
               forwardedges += [e]
               if e[0] == s:
                    break
          else:
               if(checker[0] == e[0] and checker[1] == e[1]):
                    counter -= 1
                    if counter == 0:
                         return -1
               Q.append(e)
     return forwardedges

############################

# FINISH THIS METHOD

############################

def ford_fulkerson(N, m, s, t, directed_edges):
    # You are given the following variables:
    # N - the number of vertices in the graph (INT)
    # m - the number of edges in the graph (INT)
    # s - the name of the source node (INT)
    # t - the name of the sink node (INT)
    # directed_edges: a list of lists
    # ---> Each sublist contains 3 INTs representing a directed edge in the graph:
    # ---> 0) the name of the start vertex
    # ---> 1) the name of the end vertex
    # ---> 2) the weight of the directed edge (for simplicity, this will be a positive integer!)
     #print(s, t)
     dic = sort(N, m, s, t, directed_edges)
     l = directed_edges.copy()
     for i in l:
          i += [0]
     while(True):
          forward, backward = BFS(N,s,t,l)
          path = find_path(s,t,forward)
          if path == -1:
               break
          neck = bottle_neck(s, t, path)
          for i in forward:
               for j in path:
                    if i[0] == j[0] and i[1] == j[1]:
                         i[3] += neck
                         break
          l = []
          for i in forward:
               l.append(i)
          for i in backward:
               l.append(i)
          #print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
     #print(l)
     edgeFull = []
     poplist = []
     for i in range(len(l)):
          if(l[i][2] == l[i][3]):
               edgeFull.append(l[i])
               poplist.append(i)
               dic[l[i][0]].remove(l[i][1])
     poplist.sort(reverse = True)
     for i in poplist:
          l.pop(i)
     rem = set([s])
     for i in dic:
          rem.add(i)
          for j in dic[i]:
               rem.add(j)
     number = len(rem)
     while(True):
          temp, others = BFS2(number, s, t, l)
          if temp == -1:
               break
          path = find_path2(t,s,temp)
          if path == -1:
               break
          neck = bottle_neck(s, t, path)
          for i in temp:
               for j in path:
                    if i[0] == j[0] and i[1] == j[1]:
                         i[3] += neck
                         break
               node = i[0]
               i[0] = i[1]
               i[1] = node
          l = []
          for i in temp:
               l.append(i)
          for i in others:
               l.append(i)
          print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
     ###########################################
     l+=edgeFull
     
# return a list of lists called max_flow
# max_flow should have m sublists, one for each edge in the graph:
# ---> Each sublist should contain 3 INTs:
# ---> 0) the name of the start vertex
# ---> 1) the name of the end vertex
# ---> 2) the max flow along this directed edge
# the edges may be placed into max_flow in any order
     for i in l:
          i[2] = i[3]
     max_flow = l
    
     return max_flow

def BFS2(N, s, t, directed_edges):
     Q = []
     for e in directed_edges:
          Q.append(e)
     conn= set([t])
     forwardedges = []
     checker = Q.pop()
     Q.append(checker)
     #print(checker)
     counter = 3
     while Q:
          e = Q.pop(0)
          #if e[2] == e[3]:
              # N -= 1
          if e[1] in conn and e[0] not in conn and e[2] != e[3]:
               conn.add(e[0])
               forwardedges.append([e[1], e[0], e[2], e[3]])
               #print(forwardedges)
               if e[0] == s:
                    break
          else:
               if(checker[0] == e[0] and checker[1] == e[1]):
                    counter -= 1
                    if counter == 0:
                         return -1,-1
               Q.append(e)
          #l = len(conn)
     backwardedges = Q
     return forwardedges,backwardedges
def find_path2(s,t,forward):
     Q = []
     for e in forward:
          Q.append(e)
     conn= set([t])
     forwardedges = []
     checker = Q.pop(0)
     Q.append(checker)
     counter = len(forward)
     while Q:
          #print(counter)
          e = Q.pop(0)
          if e[1] in conn and e[0] not in conn and e[2] != e[3]:
               conn.add(e[0])
               forwardedges += [e]
               if e[0] == s:
                    break
          else:
               if(checker[0] == e[0] and checker[1] == e[1]):
                    counter -= 1
                    if counter == 0:
                         return -1
               Q.append(e)
     return forwardedges

############################################

# CHANGE INPUT FILES FOR DEBUGGING HERE

############################################

def main(args=[]):
    # WHEN YOU SUBMIT TO THE AUTOGRADER, 
    # PLEASE MAKE SURE THE FOLLOWING FUNCTION LOOKS LIKE:
    Run('input', 'output')
    #Run('01_input', 'output')

if __name__ == "__main__":
    main(sys.argv[1:])    

