"""
Model a angel with openGL

Student Name: Haowei Li
Student ID: U32332746
Class: CS480
Assignment Number: 2
Due Date: Tuesday 9/21, 11:59 PM
no collabrations

The code in the file can draw lines  by left click twice, 
and can draw triangles by right click three times. The code also includes 
color interpolation.py
"""

from Component import Component
from Point import Point
import ColorType as Ct
from DisplayableCube import DisplayableCube
from DisplayableSphere import DisplayableSphere
from DisplayableCylinder import DisplayableCylinder
from DisplayableDisk import DisplayableDisk
from PIL import Image
img = Image.open("MyModelImage.jpg")
img.show()
class Angel(Component):
    """
    Define our linkage model
    """

    ##### TODO 2: Model the Creature
    # Build the class(es) of objects that could utilize your built geometric object/combination classes. E.g., you could define
    # three instances of the cyclinder trunk class and link them together to be the "limb" class of your creature. 

    components = None
    contextParent = None
    neckAngle=-90
    ShoulderAngle=30
    ElbowAngle=-30
    WristAngle=-15
    UpperFingerAngle=-5
    LowerFingerAngle = -30
    ButtAngle=30
    KneeAngle=30
    FootAngle=299
        
    def __init__(self, parent, position, display_obj=None, neckAngle=-90,ShoulderAngle=30, ElbowAngle=-30,WristAngle=-15,UpperFingerAngle=-5,LowerFingerAngle = -30,ButtAngle=30,KneeAngle=30,FootAngle=299, wingAngle=30):
        super().__init__(position, display_obj)
        self.components = []
        self.contextParent = parent
        
        self.neckAngle=neckAngle
        self.ShoulderAngle=ShoulderAngle
        self.ElbowAngle=ElbowAngle
        self.WristAngle=WristAngle
        self.UpperFingerAngle=UpperFingerAngle
        self.LowerFingerAngle = LowerFingerAngle
        self.ButtAngle=ButtAngle
        self.KneeAngle=KneeAngle
        self.FootAngle=FootAngle
        #Behaviors:
        if(neckAngle>-60):
            neckAngle=-60
        if(neckAngle<-120):
            neckAngle=-120
        if(ShoulderAngle>30):
            ShoulderAngle=30
        if(ShoulderAngle<-45):
            ShoulderAngle=-45
        if(ElbowAngle<-120):
            ElbowAngle=-120
        if(ElbowAngle>10):
            ElbowAngle=10
        if(WristAngle<-70):
            WristAngle=-70
        if(WristAngle>40):
            WristAngle=40
        if(UpperFingerAngle<-90):
            UpperFingerAngle=-90
        if(UpperFingerAngle>0):
            UpperFingerAngle=0
        if(LowerFingerAngle<-100):
            LowerFingerAngle=-100
        if(LowerFingerAngle>0):
            LowerFingerAngle=0
        if(ButtAngle<-90):
            ButtAngle=-90
        if(ButtAngle>30):
            ButtAngle=30
        if(KneeAngle>120):
            KneeAngle=120
        if(KneeAngle<0):
            KneeAngle=0
        if(FootAngle<260):
            FootAngle=260
        if(FootAngle>300):
            FootAngle=300
        if(wingAngle>60):
            wingAngle=60
        if(wingAngle<10):
            wingAngle=10
        
        linkageLength = 0.5
        #torsal                    z,y,x                                              z   y    x
        torsal = Component(Point((0, 0, 0)), DisplayableCube(self.contextParent, 1, [0.4, 0.8, 0.5]))
        torsal.setDefaultColor(Ct.BLUE)
        torsal.setDefaultAngle(90, torsal.vAxis)
        
        
        #neck                                                                                                        base top length
        neckBall = Component(Point((0, linkageLength-0.1, linkageLength/2)), DisplayableSphere(self.contextParent, 0.1, False))
        neckBall.setDefaultColor(Ct.DARKORANGE1)
        neck = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.2]))
        neck.setDefaultColor(Ct.DARKORANGE1)
        neck.setDefaultAngle(neckAngle, [1,0,0])
        
        #head
        head = Component(Point((0, 0, linkageLength-0.2)), DisplayableSphere(self.contextParent, 0.25, False))
        head.setDefaultColor(Ct.DARKORANGE1)
        #eyeballs
        leftEye = Component(Point((-0.17, -0.11, linkageLength-0.43)), DisplayableSphere(self.contextParent, 0.07, False))
        rightEye = Component(Point((-0.17, 0.11, linkageLength-0.43)), DisplayableSphere(self.contextParent, 0.07, False))
        
        leftPupil = Component(Point((-0.05,0, 0)), DisplayableSphere(self.contextParent, 0.04, False))
        leftPupil.setDefaultColor(Ct.DARKGREEN)
        rightPupil = Component(Point((-0.05, 0, 0)), DisplayableSphere(self.contextParent, 0.04, False))
        rightPupil.setDefaultColor(Ct.DARKGREEN)
        ###################################################Right Arm Side###############################################
        #upper right joint
        upperRightJoint = Component(Point((0, 0.3, linkageLength)), DisplayableSphere(self.contextParent, 0.1, False))
        upperRightJoint.setDefaultColor(Ct.DARKORANGE1)
        #upper right arm
        upperRightArm = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, linkageLength-0.1]))
        upperRightArm.setDefaultColor(Ct.DARKORANGE1)
        upperRightArm.setDefaultAngle(30-ShoulderAngle, [1,0,0])
        #right elbow
        rightElbow = Component(Point((0, 0, linkageLength-0.1)), DisplayableSphere(self.contextParent, 0.1, False))
        rightElbow.setDefaultColor(Ct.DARKORANGE1)
        #lower right arm
        lowerRightArm = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, linkageLength-0.1]))
        lowerRightArm.setDefaultColor(Ct.DARKORANGE1)
        lowerRightArm.setDefaultAngle(ElbowAngle, [0,1,0])
        #right wrist and palm
        rightWrist = Component(Point((0, 0, linkageLength-0.1)), DisplayableSphere(self.contextParent, 0.11, False))
        rightWrist.setDefaultColor(Ct.DARKORANGE1)
        rightWrist.setDefaultAngle(WristAngle, [0,1,0])
        #right fingers:
        rthumbknob = Component(Point((0, 0.3-0.35, 0.08)), DisplayableSphere(self.contextParent, 0.04, False))
        rindexknob = Component(Point((0, 0.33-0.34, 0.1)), DisplayableSphere(self.contextParent, 0.04, False))
        rmiddleknob = Component(Point((0, 0.36-0.34, 0.1)), DisplayableSphere(self.contextParent, 0.04, False))
        rringknob = Component(Point((0, 0.39-0.34, 0.1)), DisplayableSphere(self.contextParent, 0.04, False))
        rlittleknob = Component(Point((0, 0.42-0.34, 0.08)), DisplayableSphere(self.contextParent, 0.04, False))
        
        rindexknob.setDefaultColor(Ct.DARKORANGE1)
        rmiddleknob.setDefaultColor(Ct.DARKORANGE1)
        rringknob.setDefaultColor(Ct.DARKORANGE1)
        rlittleknob.setDefaultColor(Ct.DARKORANGE1)
        rthumbknob.setDefaultColor(Ct.DARKORANGE1)
        
        rthumbUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/4]))
        rindexUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/4]))
        rmiddleUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/4]))
        rringUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/4]))
        rlittleUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/6]))
        
        rlittleUpper.setDefaultAngle(-30, [1,0,0])
        rringUpper.setDefaultAngle(-20, [1,0,0])
        rmiddleUpper.setDefaultAngle(-10, [1,0,0])
        rindexUpper.setDefaultAngle(0,[1,0,0])
        rthumbUpper.setDefaultAngle(10, [1,0,0])
        
        rlittleUpper.setDefaultAngle(UpperFingerAngle,[0,1,0])
        rringUpper.setDefaultAngle(UpperFingerAngle,[0,1,0])
        rmiddleUpper.setDefaultAngle(UpperFingerAngle,[0,1,0])
        rindexUpper.setDefaultAngle(UpperFingerAngle,[0,1,0])
        rthumbUpper.setDefaultAngle(UpperFingerAngle,[0,1,0])
        
        rthumbUpper.setDefaultColor(Ct.DARKORANGE1)
        rindexUpper.setDefaultColor(Ct.DARKORANGE1)
        rmiddleUpper.setDefaultColor(Ct.DARKORANGE1)
        rringUpper.setDefaultColor(Ct.DARKORANGE1)
        rlittleUpper.setDefaultColor(Ct.DARKORANGE1)
        
        rthumbJoint = Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.03, False))
        rindexJoint = Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.03, False))
        rmiddleJoint = Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.03, False))
        rringJoint = Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.03, False))
        rlittleJoint = Component(Point((0, 0, linkageLength/6)), DisplayableSphere(self.contextParent, 0.03, False))
        
        rthumbJoint.setDefaultColor(Ct.DARKORANGE1)
        rindexJoint.setDefaultColor(Ct.DARKORANGE1)
        rmiddleJoint.setDefaultColor(Ct.DARKORANGE1)
        rringJoint.setDefaultColor(Ct.DARKORANGE1)
        rlittleJoint.setDefaultColor(Ct.DARKORANGE1)
        
        rthumbLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/4]))
        rindexLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/4]))
        rmiddleLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/4]))
        rringLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/4]))
        rlittleLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/6]))
        
        rthumbLower.setDefaultAngle(LowerFingerAngle, [0,1,0])
        rindexLower.setDefaultAngle(LowerFingerAngle, [0,1,0])
        rmiddleLower.setDefaultAngle(LowerFingerAngle, [0,1,0])
        rringLower.setDefaultAngle(LowerFingerAngle, [0,1,0])
        rlittleLower.setDefaultAngle(LowerFingerAngle, [0,1,0])
        
        rthumbLower.setDefaultColor(Ct.DARKORANGE1)
        rindexLower.setDefaultColor(Ct.DARKORANGE1)
        rmiddleLower.setDefaultColor(Ct.DARKORANGE1)
        rringLower.setDefaultColor(Ct.DARKORANGE1)
        rlittleLower.setDefaultColor(Ct.DARKORANGE1)
        # for the right finger tips
        rtt= Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.02, False))
        rit= Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.02, False))
        rmt= Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.02, False))
        rrt= Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.02, False))
        rlt= Component(Point((0, 0, linkageLength/6)), DisplayableSphere(self.contextParent, 0.02, False))
        
        rtt.setDefaultColor(Ct.DARKORANGE1)
        rit.setDefaultColor(Ct.DARKORANGE1)
        rmt.setDefaultColor(Ct.DARKORANGE1)
        rrt.setDefaultColor(Ct.DARKORANGE1)
        rlt.setDefaultColor(Ct.DARKORANGE1)
        ################################################Left Arm Side################################################
        #upper left joint
        upperLeftJoint = Component(Point((0, 0.3, 0)), DisplayableSphere(self.contextParent, 0.1, False))
        upperLeftJoint.setDefaultColor(Ct.DARKORANGE1)
        #upper Left arm
        upperLeftArm = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, linkageLength-0.1]))
        upperLeftArm.setDefaultColor(Ct.DARKORANGE1)
        upperLeftArm.setDefaultAngle(180, [0,1,0])
        
        upperLeftArm.setDefaultAngle(-30+ShoulderAngle, [1,0,0])
        #Left elbow
        LeftElbow = Component(Point((0, 0, linkageLength-0.1)), DisplayableSphere(self.contextParent, 0.1, False))
        LeftElbow.setDefaultColor(Ct.DARKORANGE1)
        #lower Left arm
        lowerLeftArm = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, linkageLength-0.1]))
        lowerLeftArm.setDefaultColor(Ct.DARKORANGE1)
        lowerLeftArm.setDefaultAngle(-ElbowAngle, [0,1,0])
        #Left wrist and palm
        LeftWrist = Component(Point((0, 0, linkageLength-0.1)), DisplayableSphere(self.contextParent, 0.11, False))
        LeftWrist.setDefaultColor(Ct.DARKORANGE1)
        LeftWrist.setDefaultAngle(-WristAngle, [0,1,0])
        #Left fingers:
        lthumbknob = Component(Point((0, 0.3-0.35, 0.08)), DisplayableSphere(self.contextParent, 0.04, False))
        lindexknob = Component(Point((0, 0.33-0.34, 0.1)), DisplayableSphere(self.contextParent, 0.04, False))
        lmiddleknob = Component(Point((0, 0.36-0.34, 0.1)), DisplayableSphere(self.contextParent, 0.04, False))
        lringknob = Component(Point((0, 0.39-0.34, 0.1)), DisplayableSphere(self.contextParent, 0.04, False))
        llittleknob = Component(Point((0, 0.42-0.34, 0.08)), DisplayableSphere(self.contextParent, 0.04, False))
        
        lindexknob.setDefaultColor(Ct.DARKORANGE1)
        lmiddleknob.setDefaultColor(Ct.DARKORANGE1)
        lringknob.setDefaultColor(Ct.DARKORANGE1)
        llittleknob.setDefaultColor(Ct.DARKORANGE1)
        lthumbknob.setDefaultColor(Ct.DARKORANGE1)
        
        lthumbUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/4]))
        lindexUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/4]))
        lmiddleUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/4]))
        lringUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/4]))
        llittleUpper = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.03, linkageLength/6]))
        
        llittleUpper.setDefaultAngle(-30, [1,0,0])
        lringUpper.setDefaultAngle(-20, [1,0,0])
        lmiddleUpper.setDefaultAngle(-10, [1,0,0])
        rindexUpper.setDefaultAngle(0,[1,0,0])
        lthumbUpper.setDefaultAngle(10, [1,0,0])
        
        llittleUpper.setDefaultAngle(-UpperFingerAngle,[0,1,0])
        lringUpper.setDefaultAngle(-UpperFingerAngle,[0,1,0])
        lmiddleUpper.setDefaultAngle(-UpperFingerAngle,[0,1,0])
        lindexUpper.setDefaultAngle(-UpperFingerAngle,[0,1,0])
        lthumbUpper.setDefaultAngle(-UpperFingerAngle,[0,1,0])
        
        lthumbUpper.setDefaultColor(Ct.DARKORANGE1)
        lindexUpper.setDefaultColor(Ct.DARKORANGE1)
        lmiddleUpper.setDefaultColor(Ct.DARKORANGE1)
        lringUpper.setDefaultColor(Ct.DARKORANGE1)
        llittleUpper.setDefaultColor(Ct.DARKORANGE1)
        
        lthumbJoint = Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.03, False))
        lindexJoint = Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.03, False))
        lmiddleJoint = Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.03, False))
        lringJoint = Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.03, False))
        llittleJoint = Component(Point((0, 0, linkageLength/6)), DisplayableSphere(self.contextParent, 0.03, False))
        
        lthumbJoint.setDefaultColor(Ct.DARKORANGE1)
        lindexJoint.setDefaultColor(Ct.DARKORANGE1)
        lmiddleJoint.setDefaultColor(Ct.DARKORANGE1)
        lringJoint.setDefaultColor(Ct.DARKORANGE1)
        llittleJoint.setDefaultColor(Ct.DARKORANGE1)
        
        lthumbLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/4]))
        lindexLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/4]))
        lmiddleLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/4]))
        lringLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/4]))
        llittleLower = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.03, 0.02, linkageLength/6]))
        
        lthumbLower.setDefaultColor(Ct.DARKORANGE1)
        lindexLower.setDefaultColor(Ct.DARKORANGE1)
        lmiddleLower.setDefaultColor(Ct.DARKORANGE1)
        lringLower.setDefaultColor(Ct.DARKORANGE1)
        llittleLower.setDefaultColor(Ct.DARKORANGE1)
        
        lthumbLower.setDefaultAngle(-LowerFingerAngle, [0,1,0])
        lindexLower.setDefaultAngle(-LowerFingerAngle, [0,1,0])
        lmiddleLower.setDefaultAngle(-LowerFingerAngle, [0,1,0])
        lringLower.setDefaultAngle(-LowerFingerAngle, [0,1,0])
        llittleLower.setDefaultAngle(-LowerFingerAngle, [0,1,0])
        # for the Left finger tips
        ltt= Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.02, False))
        lit= Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.02, False))
        lmt= Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.02, False))
        lrt= Component(Point((0, 0, linkageLength/4)), DisplayableSphere(self.contextParent, 0.02, False))
        llt= Component(Point((0, 0, linkageLength/6)), DisplayableSphere(self.contextParent, 0.02, False))
        
        ltt.setDefaultColor(Ct.DARKORANGE1)
        lit.setDefaultColor(Ct.DARKORANGE1)
        lmt.setDefaultColor(Ct.DARKORANGE1)
        lrt.setDefaultColor(Ct.DARKORANGE1)
        llt.setDefaultColor(Ct.DARKORANGE1)
################################################Right Leg Side################################################
        rightButt = Component(Point((0, -linkageLength+0.1, linkageLength-0.1)), DisplayableSphere(self.contextParent, 0.15, False))
        rightButt.setDefaultColor(Ct.BLUE)
        rightButt.setDefaultAngle(85,[1,0,0])
        rightButt.setDefaultAngle(-10,[0,0,1])
        rightButt.setDefaultAngle(ButtAngle,[0,1,0])
        upperRightLeg = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.15, 0.15, linkageLength]))
        upperRightLeg.setDefaultColor(Ct.BLUE)
        rightKnee =  Component(Point((0, 0, linkageLength)), DisplayableSphere(self.contextParent, 0.14, False))
        rightKnee.setDefaultColor(Ct.DARKORANGE1)
        rightKnee.setDefaultAngle(KneeAngle,[0,1,0])
        lowerRightLeg = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.14, 0.14, linkageLength]))
        lowerRightLeg.setDefaultColor(Ct.DARKORANGE1)
        rightAnkel = Component(Point((0, 0, linkageLength)), DisplayableSphere(self.contextParent, 0.15, False))
        rightAnkel.setDefaultColor(Ct.DARKORANGE1)
        rightShoes = Component(Point((0.2, 0, 0.05)), DisplayableCube(self.contextParent, 1, [0.2, 0.3, linkageLength]))
        rightShoes.setDefaultColor(Ct.DODGERBLUE)
        rightShoes.setDefaultAngle(FootAngle,[0,1,0])
################################################Left Leg Side################################################
        leftButt = Component(Point((0, -linkageLength+0.1, 0.1)), DisplayableSphere(self.contextParent, 0.15, False))
        leftButt.setDefaultColor(Ct.BLUE)
        leftButt.setDefaultAngle(-265,[1,0,0])
        leftButt.setDefaultAngle(10,[0,0,1])
        leftButt.setDefaultAngle(ButtAngle,[0,1,0])
        upperleftLeg = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.15, 0.15, linkageLength]))
        upperleftLeg.setDefaultColor(Ct.BLUE)
        leftKnee =  Component(Point((0, 0, linkageLength)), DisplayableSphere(self.contextParent, 0.14, False))
        leftKnee.setDefaultColor(Ct.DARKORANGE1)
        leftKnee.setDefaultAngle(KneeAngle,[0,1,0])
        lowerleftLeg = Component(Point((0, 0, 0)), DisplayableCylinder(self.contextParent, 1, [0.14, 0.14, linkageLength]))
        lowerleftLeg.setDefaultColor(Ct.DARKORANGE1)
        leftAnkel = Component(Point((0, 0, linkageLength)), DisplayableSphere(self.contextParent, 0.15, False))
        leftAnkel.setDefaultColor(Ct.DARKORANGE1)
        leftShoes = Component(Point((0.2, 0, 0.05)), DisplayableCube(self.contextParent, 1, [0.2, 0.3, linkageLength]))
        leftShoes.setDefaultColor(Ct.DODGERBLUE)
        leftShoes.setDefaultAngle(FootAngle,[0,1,0])
##########################################Right Wing #######################################
        rwing1 = Component(Point((0.2, 0.2, 0.4)), DisplayableCube(self.contextParent, 1, [0.15, 0.3, linkageLength]))
        rwing1.setDefaultColor(Ct.SILVER)
        rwing1.setDefaultAngle(90, [0,1,0])
        rwing1.setDefaultAngle(180, [0,0,1])
        rwing1.setDefaultAngle(20, [1,0,0])
        rwing1Joint = Component(Point((0, 0.15, linkageLength)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.3]))
        rwing1Joint.setDefaultAngle(90, [1,0,0])
        rwing1Joint.setDefaultColor(Ct.SILVER)
        rwing1CapTop =  Component(Point((0, 0.01, 0)), DisplayableSphere(self.contextParent, 0.1, None))
        rwing1CapTop.setDefaultColor(Ct.SILVER)
        rwing1CapBot =  Component(Point((0, 0,0.3)), DisplayableSphere(self.contextParent, 0.1, None))
        rwing1CapBot.setDefaultColor(Ct.SILVER)
        
        
        rwing2 = Component(Point((0, 0, 0.15)), DisplayableCube(self.contextParent, 1, [0.13, 0.4, linkageLength]))
        rwing2.setDefaultColor(Ct.SILVER)
        rwing2.setDefaultAngle(-90,[1,0,0])
        rwing2.setDefaultAngle(wingAngle,[0,1,0])
        rwing2Joint = Component(Point((0, 0.2, linkageLength)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.4]))
        rwing2Joint.setDefaultAngle(90, [1,0,0])
        rwing2Joint.setDefaultColor(Ct.SILVER)
        rwing2CapTop =  Component(Point((0, 0.01, 0)), DisplayableSphere(self.contextParent, 0.1, None))
        rwing2CapTop.setDefaultColor(Ct.SILVER)
        rwing2CapBot =  Component(Point((0, 0,0.4)), DisplayableSphere(self.contextParent, 0.1, None))
        rwing2CapBot.setDefaultColor(Ct.SILVER)
        
        
        rwing3 = Component(Point((0, 0, 0.2)), DisplayableCube(self.contextParent, 1, [0.11, 0.6, linkageLength]))
        rwing3.setDefaultColor(Ct.SILVER)
        rwing3.setDefaultAngle(-90,[1,0,0])
        rwing3.setDefaultAngle(wingAngle,[0,1,0])
        rwing3Joint = Component(Point((0, 0.25, linkageLength)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.5]))
        rwing3Joint.setDefaultAngle(90, [1,0,0])
        rwing3Joint.setDefaultColor(Ct.SILVER)
        rwing3CapTop =  Component(Point((0, 0.01, 0)), DisplayableSphere(self.contextParent, 0.1, None))
        rwing3CapTop.setDefaultColor(Ct.SILVER)
        rwing3CapBot =  Component(Point((0, 0,0.5)), DisplayableSphere(self.contextParent, 0.1, None))
        rwing3CapBot.setDefaultColor(Ct.SILVER)
        
        rwing4 = Component(Point((0, 0, 0.25)), DisplayableCube(self.contextParent, 1, [0.09, 0.7, linkageLength]))
        rwing4.setDefaultColor(Ct.SILVER)
        rwing4.setDefaultAngle(-90,[1,0,0])
        rwing4.setDefaultAngle(wingAngle,[0,1,0])
        rwing4Joint = Component(Point((0, 0.25, linkageLength)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.5]))
        rwing4Joint.setDefaultAngle(90, [1,0,0])
        rwing4Joint.setDefaultColor(Ct.SILVER)
        rwing4CapTop =  Component(Point((0, 0.01, 0)), DisplayableSphere(self.contextParent, 0.1, None))
        rwing4CapTop.setDefaultColor(Ct.SILVER)
        rwing4CapBot =  Component(Point((0, 0,0.5)), DisplayableSphere(self.contextParent, 0.1, None))
        rwing4CapBot.setDefaultColor(Ct.SILVER)
        
        

        
        
##########################################Left Wing #######################################
        lwing1 = Component(Point((0.2, 0.2, 0.1)), DisplayableCube(self.contextParent, 1, [0.15, 0.3, linkageLength]))
        lwing1.setDefaultColor(Ct.SILVER)
        lwing1.setDefaultAngle(90, [0,1,0])
        lwing1.setDefaultAngle(-360,[0,0,1])
        lwing1.setDefaultAngle(-20, [1,0,0])
        lwing1Joint = Component(Point((0, 0.15, linkageLength)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.3]))
        lwing1Joint.setDefaultAngle(90, [1,0,0])
        lwing1Joint.setDefaultColor(Ct.SILVER)
        lwing1CapTop =  Component(Point((0, 0.01, 0)), DisplayableSphere(self.contextParent, 0.1, None))
        lwing1CapTop.setDefaultColor(Ct.SILVER)
        lwing1CapBot =  Component(Point((0, 0,0.3)), DisplayableSphere(self.contextParent, 0.1, None))
        lwing1CapBot.setDefaultColor(Ct.SILVER)
        
        
        lwing2 = Component(Point((0, 0, 0.15)), DisplayableCube(self.contextParent, 1, [0.13, 0.4, linkageLength]))
        lwing2.setDefaultColor(Ct.SILVER)
        lwing2.setDefaultAngle(-90,[1,0,0])
        lwing2.setDefaultAngle(wingAngle,[0,1,0])
        lwing2Joint = Component(Point((0, 0.2, linkageLength)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.4]))
        lwing2Joint.setDefaultAngle(90, [1,0,0])
        lwing2Joint.setDefaultColor(Ct.SILVER)
        lwing2CapTop =  Component(Point((0, 0.01, 0)), DisplayableSphere(self.contextParent, 0.1, None))
        lwing2CapTop.setDefaultColor(Ct.SILVER)
        lwing2CapBot =  Component(Point((0, 0,0.4)), DisplayableSphere(self.contextParent, 0.1, None))
        lwing2CapBot.setDefaultColor(Ct.SILVER)
        
        
        lwing3 = Component(Point((0, 0, 0.2)), DisplayableCube(self.contextParent, 1, [0.11, 0.6, linkageLength]))
        lwing3.setDefaultColor(Ct.SILVER)
        lwing3.setDefaultAngle(-90,[1,0,0])
        lwing3.setDefaultAngle(wingAngle,[0,1,0])
        lwing3Joint = Component(Point((0, 0.25, linkageLength)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.5]))
        lwing3Joint.setDefaultAngle(90, [1,0,0])
        lwing3Joint.setDefaultColor(Ct.SILVER)
        lwing3CapTop =  Component(Point((0, 0.01, 0)), DisplayableSphere(self.contextParent, 0.1, None))
        lwing3CapTop.setDefaultColor(Ct.SILVER)
        lwing3CapBot =  Component(Point((0, 0,0.5)), DisplayableSphere(self.contextParent, 0.1, None))
        lwing3CapBot.setDefaultColor(Ct.SILVER)
        
        lwing4 = Component(Point((0, 0, 0.25)), DisplayableCube(self.contextParent, 1, [0.09, 0.7, linkageLength]))
        lwing4.setDefaultColor(Ct.SILVER)
        lwing4.setDefaultAngle(-90,[1,0,0])
        lwing4.setDefaultAngle(wingAngle,[0,1,0])
        lwing4Joint = Component(Point((0, 0.25, linkageLength)), DisplayableCylinder(self.contextParent, 1, [0.1, 0.1, 0.5]))
        lwing4Joint.setDefaultAngle(90, [1,0,0])
        lwing4Joint.setDefaultColor(Ct.SILVER)
        lwing4CapTop =  Component(Point((0, 0.01, 0)), DisplayableSphere(self.contextParent, 0.1, None))
        lwing4CapTop.setDefaultColor(Ct.SILVER)
        lwing4CapBot =  Component(Point((0, 0,0.5)), DisplayableSphere(self.contextParent, 0.1, None))
        lwing4CapBot.setDefaultColor(Ct.SILVER)
        
        

###########################torsal and head##########################################
        self.addChild(torsal)
        torsal.addChild(neckBall)
        neckBall.addChild(neck)
        neck.addChild(head)
        head.addChild(leftEye)
        head.addChild(rightEye)
        leftEye.addChild(leftPupil)
        rightEye.addChild(rightPupil)
#####################right arm side###############################
        torsal.addChild(upperRightJoint)
        upperRightJoint.addChild(upperRightArm)
        upperRightArm.addChild(rightElbow)
        rightElbow.addChild(lowerRightArm)
        lowerRightArm.addChild(rightWrist)
        
        rightWrist.addChild(rthumbknob)
        rightWrist.addChild(rindexknob)
        rightWrist.addChild(rmiddleknob)
        rightWrist.addChild(rringknob)
        rightWrist.addChild(rlittleknob)
        
        rthumbknob.addChild(rthumbUpper)
        rindexknob.addChild(rindexUpper)
        rmiddleknob.addChild(rmiddleUpper)
        rringknob.addChild(rringUpper)
        rlittleknob.addChild(rlittleUpper)
        
        rthumbUpper.addChild(rthumbJoint)
        rindexUpper.addChild(rindexJoint)
        rmiddleUpper.addChild(rmiddleJoint)
        rringUpper.addChild(rringJoint)
        rlittleUpper.addChild(rlittleJoint)
        
        rthumbJoint.addChild(rthumbLower)
        rindexJoint.addChild(rindexLower)
        rmiddleJoint.addChild(rmiddleLower)
        rringJoint.addChild(rringLower)
        rlittleJoint.addChild(rlittleLower)
        
        rthumbLower.addChild(rtt)
        rindexLower.addChild(rit)
        rmiddleLower.addChild(rmt)
        rringLower.addChild(rrt)
        rlittleLower.addChild(rlt)
###################Left arm side############################
        torsal.addChild(upperLeftJoint)
        upperLeftJoint.addChild(upperLeftArm)
        upperLeftArm.addChild(LeftElbow)
        LeftElbow.addChild(lowerLeftArm)
        lowerLeftArm.addChild(LeftWrist)
        
        LeftWrist.addChild(lthumbknob)
        LeftWrist.addChild(lindexknob)
        LeftWrist.addChild(lmiddleknob)
        LeftWrist.addChild(lringknob)
        LeftWrist.addChild(llittleknob)
        
        lthumbknob.addChild(lthumbUpper)
        lindexknob.addChild(lindexUpper)
        lmiddleknob.addChild(lmiddleUpper)
        lringknob.addChild(lringUpper)
        llittleknob.addChild(llittleUpper)
        
        lthumbUpper.addChild(lthumbJoint)
        lindexUpper.addChild(lindexJoint)
        lmiddleUpper.addChild(lmiddleJoint)
        lringUpper.addChild(lringJoint)
        llittleUpper.addChild(llittleJoint)
        
        lthumbJoint.addChild(lthumbLower)
        lindexJoint.addChild(lindexLower)
        lmiddleJoint.addChild(lmiddleLower)
        lringJoint.addChild(lringLower)
        llittleJoint.addChild(llittleLower)
        
        lthumbLower.addChild(ltt)
        lindexLower.addChild(lit)
        lmiddleLower.addChild(lmt)
        lringLower.addChild(lrt)
        llittleLower.addChild(llt)
###########################right leg side##########################
        torsal.addChild(rightButt)
        rightButt.addChild(upperRightLeg)
        upperRightLeg.addChild(rightKnee)
        rightKnee.addChild(lowerRightLeg)
        lowerRightLeg.addChild(rightAnkel)
        rightAnkel.addChild(rightShoes)
###########################left leg side##########################
        torsal.addChild(leftButt)
        leftButt.addChild(upperleftLeg)
        upperleftLeg.addChild(leftKnee)
        leftKnee.addChild(lowerleftLeg)
        lowerleftLeg.addChild(leftAnkel)
        leftAnkel.addChild(leftShoes)
###########################right wing###############################
        torsal.addChild(rwing1)
        rwing1.addChild(rwing1Joint)
        rwing1Joint.addChild(rwing1CapTop)
        rwing1CapTop.addChild(rwing1CapBot)
        rwing1Joint.addChild(rwing2)
        
        rwing2.addChild(rwing2Joint)
        rwing2Joint.addChild(rwing2CapTop)
        rwing2CapTop.addChild(rwing2CapBot)
        rwing2Joint.addChild(rwing3)
        
        rwing3.addChild(rwing3Joint)
        rwing3Joint.addChild(rwing3CapTop)
        rwing3CapTop.addChild(rwing3CapBot)
        rwing3Joint.addChild(rwing4)
        
        rwing4.addChild(rwing4Joint)
        rwing4Joint.addChild(rwing3CapTop)
        rwing4CapTop.addChild(rwing3CapBot)
        
###########################left wing###############################
        torsal.addChild(lwing1)
        lwing1.addChild(lwing1Joint)
        lwing1Joint.addChild(lwing1CapTop)
        lwing1CapTop.addChild(lwing1CapBot)
        lwing1Joint.addChild(lwing2)
        
        lwing2.addChild(lwing2Joint)
        lwing2Joint.addChild(lwing2CapTop)
        lwing2CapTop.addChild(lwing2CapBot)
        lwing2Joint.addChild(lwing3)
        
        lwing3.addChild(lwing3Joint)
        lwing3Joint.addChild(lwing3CapTop)
        lwing3CapTop.addChild(lwing3CapBot)
        lwing3Joint.addChild(lwing4)
        
        lwing4.addChild(lwing4Joint)
        lwing4Joint.addChild(lwing3CapTop)
        lwing4CapTop.addChild(lwing3CapBot)
        
        
#########################range setup###############################
        neck.uRange = [-120,-60]
        neck.vRange = [-30,30]
        neck.wRange = [-30,30]
        
        leftEye.uRange = [0,0]
        rightEye.uRange = [0,0]
        leftEye.vRange = [-10,30]
        rightEye.vRange = [-10,30]
        leftEye.wRange = [-15,40]
        rightEye.wRange = [-40,15]
        
        upperRightArm.uRange = [-70,80]
        upperLeftArm.uRange = [-80,70] #[-260,-100]
        upperRightArm.vRange = [-90,30]
        upperLeftArm.vRange = [150,270]#upperRightArm.vRange
        upperRightArm.wRange = [-70,80]
        upperLeftArm.wRange = upperRightArm.wRange
        
        lowerRightArm.uRange = [-70,80]
        lowerLeftArm.uRange = lowerRightArm.uRange
        lowerRightArm.vRange = [-90,30]
        lowerLeftArm.vRange = [-30,90]
        lowerRightArm.wRange = [0,0]
        lowerLeftArm.wRange = lowerRightArm.wRange
        
        rightWrist.uRange = [-40,40]
        LeftWrist.uRange = rightWrist.uRange
        rightWrist.vRange = [-90,30]
        LeftWrist.vRange = [-30,90]
        rightWrist.wRange = [-70,80]
        LeftWrist.wRange = [-80,70]
        
        
        lthumbUpper.uRange = [-30,30]
        lindexUpper.uRange = [-20,10]
        lmiddleUpper.uRange = [-10,10]
        lringUpper.uRange = [-20,0]
        llittleUpper.uRange = [-60,30]
        
        rthumbUpper.uRange = [-30,30]
        rindexUpper.uRange = [-20,10]
        rmiddleUpper.uRange = [-10,10]
        rringUpper.uRange = [-20,0]
        rlittleUpper.uRange = [-60,30]
        
        lthumbUpper.vRange = [0,90]
        lindexUpper.vRange = [0,90]
        lmiddleUpper.vRange = [0,90]
        lringUpper.vRange = [0,90]
        llittleUpper.vRange = [0,90]
        
        rthumbUpper.vRange = [-90,0]
        rindexUpper.vRange = [-90,0]
        rmiddleUpper.vRange = [-90,0]
        rringUpper.vRange = [-90,0]
        rlittleUpper.vRange = [-90,0]
        
        lthumbUpper.wRange = [0,0]
        lindexUpper.wRange = [0,0]
        lmiddleUpper.wRange = [0,0]
        lringUpper.wRange = [0,0]
        llittleUpper.wRange = [0,0]
        
        rthumbUpper.wRange = lthumbUpper.wRange
        rindexUpper.wRange = lindexUpper.wRange
        rmiddleUpper.wRange = lmiddleUpper.wRange
        rringUpper.wRange = lringUpper.wRange
        rlittleUpper.wRange = llittleUpper.wRange
        
        
        
        lthumbLower.uRange = [0,0]
        lindexLower.uRange = [0,0]
        lmiddleLower.uRange = [0,0]
        lringLower.uRange = [0,0]
        llittleLower.uRange = [0,0]
        
        rthumbLower.uRange = lthumbLower.uRange
        rindexLower.uRange = lindexLower.uRange
        rmiddleLower.uRange = lmiddleLower.uRange
        rringLower.uRange = lringLower.uRange
        rlittleLower.uRange = llittleLower.uRange
        
        lthumbLower.vRange = [0,90]
        lindexLower.vRange = [0,90]
        lmiddleLower.vRange = [0,90]
        lringLower.vRange = [0,90]
        llittleLower.vRange = [0,90]
        
        rthumbLower.vRange = [-90,0]
        rindexLower.vRange = [-90,0]
        rmiddleLower.vRange = [-90,0]
        rringLower.vRange = [-90,0]
        rlittleLower.vRange = [-90,0]
        
        lthumbLower.wRange = [0,0]
        lindexLower.wRange = [0,0]
        lmiddleLower.wRange = [0,0]
        lringLower.wRange = [0,0]
        llittleLower.wRange = [0,0]
        
        rthumbLower.wRange = lthumbLower.wRange
        rindexLower.wRange = lindexLower.wRange
        rmiddleLower.wRange = lmiddleLower.wRange
        rringLower.wRange = lringLower.wRange
        rlittleLower.wRange = llittleLower.wRange
        
        rightButt.uRange = [0,90]
        leftButt.uRange = [-270,-180]
        rightButt.vRange = [-90,30]
        leftButt.vRange = rightButt.vRange
        rightButt.wRange = [0,0]
        leftButt.wRange = rightButt.wRange
        
        rightKnee.uRange = [0,0]
        leftKnee.uRange = [0,0]
        rightKnee.vRange = [0,90]
        leftKnee.vRange = rightKnee.vRange
        rightKnee.wRange = [0,0]
        leftKnee.wRange = rightKnee.wRange
        
        rightShoes.uRange = [0,0]
        leftShoes.uRange = rightShoes.uRange
        rightShoes.vRange = [270,290]
        leftShoes.vRange = rightShoes.vRange
        rightShoes.wRange = [-30,30]
        leftShoes.wRange = rightShoes.wRange
        
        rwing1.uRange=[-10,30]
        lwing1.uRange=[-380,-340]
        rwing1.vRange=[90,90]
        lwing1.vRange=[90,90]
        rwing1.wRange=[180,180]
        lwing1.wRange=[0,0]
        
        
        rwing2.uRange=[-90,-90]
        lwing2.uRange=[-90,-90]
        rwing2.vRange=[10,60]
        lwing2.vRange=[10,60]
        rwing2.wRange=[0,0]
        lwing2.wRange=[0,0]
        
        
        
        rwing3.uRange=[-90,-90]
        lwing3.uRange=[-90,-90]
        rwing3.vRange=[10,60]
        lwing3.vRange=[10,60]
        rwing3.wRange=[0,0]
        lwing3.wRange=[0,0]
        
        rwing4.uRange=[-90,-90]
        lwing4.uRange=[-90,-90]
        rwing4.vRange=[10,60]
        lwing4.vRange=[10,60]
        rwing4.wRange=[0,0]
        lwing4.wRange=[0,0]
        
        
        
        self.components = [neck,leftEye,rightEye,upperRightArm,upperLeftArm,lowerRightArm,lowerLeftArm,rightWrist,LeftWrist,
                           lthumbUpper,lindexUpper,lmiddleUpper,lringUpper,llittleUpper,
                           rthumbUpper,rindexUpper,rmiddleUpper,rringUpper,rlittleUpper,
                           lthumbLower,lindexLower,lmiddleLower,lringLower,llittleLower,
                           rthumbLower,rindexLower,rmiddleLower,rringLower,rlittleLower,
                           rightButt,leftButt,rightKnee,leftKnee,rightShoes,leftShoes,
                           rwing1,lwing1,rwing2,lwing2,rwing3,lwing3,rwing4,lwing4]

