'''
This is the main class
It will place "Angel" in the center of the 3D space

Student Name: Haowei Li
Student ID: U32332746
Class: CS480
Assignment Number: 2
Due Date: Tuesday 10/12, 11:59 PM
no collabrations

The code in the file can draw lines  by left click twice, 
and can draw triangles by right click three times. The code also includes 
color interpolation.py
'''
import os
import wx
import time
import math
import random
import numpy as np

from Point import Point
import ColorType as CT
from ColorType import ColorType
from Quaternion import Quaternion
from Component import Component
from DisplayableCube import DisplayableCube
from CanvasBase import CanvasBase
from ModelLinkage import ModelLinkage
from ModelAxes import ModelAxes
from Angel import Angel
from DisplayableWings import DisplayableWings
try:
    import wx
    from wx import glcanvas
except ImportError:
    raise ImportError("Required dependency wxPython not present")
try:
    # From pip package "Pillow"
    from PIL import Image
except:
    print("Need to install PIL package. Pip package name is Pillow")
    raise ImportError
try:
    import OpenGL

    try:
        import OpenGL.GL as gl
        import OpenGL.GLU as glu
        import OpenGL.GLUT as glut  # this fails on OS X 11.x
    except ImportError:
        from ctypes import util

        orig_util_find_library = util.find_library


        def new_util_find_library(name):
            res = orig_util_find_library(name)
            if res:
                return res
            return '/System/Library/Frameworks/' + name + '.framework/' + name


        util.find_library = new_util_find_library
        import OpenGL.GL as gl
        import OpenGL.GLU as glu
        import OpenGL.GLUT as glut
except ImportError:
    raise ImportError("Required dependency PyOpenGL not present")


class Sketch(CanvasBase):
    """
    Drawing methods and interrupt methods will be implemented in this class.
    
    Variable Instruction:
        * debug(int): Define debug level for log printing

        * 0 for stable version, minimum log is printed
        * 1 will print general logs for lines and triangles
        * 2 will print more details and do some type checking, which might be helpful in debugging

        
    Method Instruction:
        
        
    Here are the list of functions you need to override:
        * Interrupt_MouseL: Used to deal with mouse click interruption. Canvas will be refreshed with updated buff
        * Interrupt_MouseLeftDragging: Used to deal with mouse dragging interruption.
        * Interrupt_Keyboard: Used to deal with keyboard press interruption. Use this to add new keys or new methods
        
    Here are some public variables in parent class you might need:
        
        
    """
    context = None

    debug = 1

    hearts = Image.open("hearts.jpg")
    heartsRGB = hearts.convert("RGB")
    
    #print(heartsRGB.width)
    
    
    
    last_mouse_leftPosition = None
    components = None
    select_obj_index = -1  # index in components
    select_axis_index = -1  # index of select axis
    multi = False
    multiIndex = [-1,-1]
    select_color = [ColorType(1, 0, 0), ColorType(0, 1, 0), ColorType(0, 0, 1)]
    test_case_index = 0
    def __init__(self, parent):
        """
        Init everything. You should set your model here.
        """
        super(Sketch, self).__init__(parent)
        # prepare OpenGL context
        self.context = glcanvas.GLContext(self)
        # Initialize Parameters
        self.last_mouse_leftPosition = [0, 0]
        ##### TODO 3: Import Your Creature
        #creature = ModelLinkage(self, Point((0, 0, 0)))
        #self.topLevelComponent.addChild(creature)
        # You should instance your creature class here, and add it as self.topLevelComponent's Child

        ##### TODO 4: Define creature's joint behavior
        neckAngle=-90
        ShoulderAngle=0
        ElbowAngle=0
        WristAngle=-0
        UpperFingerAngle=0
        LowerFingerAngle=0
        ButtAngle=0
        KneeAngle=0
        FootAngle=270
        wingAngle=30
        creature = Angel(self, Point((0, 0, 0)),None,neckAngle,ShoulderAngle, ElbowAngle,WristAngle,UpperFingerAngle,LowerFingerAngle,ButtAngle,KneeAngle,FootAngle, wingAngle)
        
       

        self.topLevelComponent.addChild(creature)
        # Requirements:
        #   1. Set a reasonable rotation range for each joint,
        #      so that creature won't intersect itself or bend in unnatural way
        #   2. Orientation of joint rotations for the left and right parts should mirror each other.

        #m1 = ModelAxes(self, Point((-1, -1, -1)))  # coordinate system with x, y, z axes
        #m2 = ModelLinkage(self, Point((0, 0, 0)))  # our model linkage
        #temporar
        #self.topLevelComponent.addChild(m1)
        #self.topLevelComponent.addChild(m2)

        #self.components = m1.components + m2.components
        self.components = creature.components
        
        self.test_case_list = [self.test0,
                               self.test1,
                               self.test2,
                               self.test3,
                               self.test4,
                               self.test5]
    def colorReset(self):
        for i in range(0,len(self.components)):
            self.components[i].reset("color")
    def Interrupt_Scroll(self, wheelRotation):
        """
        When mouse wheel rotating detected, do following things

        :param wheelRotation: mouse wheel changes, normally +120 or -120
        :return: None
        """
        wheelChange = wheelRotation / abs(wheelRotation)  # normalize wheel change
        if self.multi ==False and len(self.components) > self.select_obj_index >= 0:
            self.components[self.select_obj_index].rotate(wheelChange * 5,
                                                          self.components[self.select_obj_index].
                                                          axisBucket[self.select_axis_index])
        else:
            if(len(self.multiIndex)==2):
                if(self.multiIndex[0]==35):
                    self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                elif(self.multiIndex[0]==29):
                    self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                
                    if(self.select_axis_index==1):
                        self.components[self.multiIndex[1]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    else:
                        self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                      self.components[self.select_obj_index].
                                                                      axisBucket[self.select_axis_index])
                else:
                    self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
            elif(len(self.multiIndex)==4):
                if(self.multiIndex[0]==35):
                    self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[2]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[3]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                elif(self.multiIndex[0]==29):
                    self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                
                    if(self.select_axis_index==1):
                        self.components[self.multiIndex[1]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    else:
                        self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                      self.components[self.select_obj_index].
                                                                      axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[2]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    
                    self.components[self.multiIndex[3]].rotate(wheelChange * 5,
                                                                      self.components[self.select_obj_index].
                                                                      axisBucket[self.select_axis_index])
                else:
                    self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[2]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    
                    if(self.select_axis_index==0):
                        self.components[self.multiIndex[3]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    else:
                        self.components[self.multiIndex[3]].rotate(-wheelChange * 5,
                                                                      self.components[self.select_obj_index].
                                                                      axisBucket[self.select_axis_index])
            elif(len(self.multiIndex)==6):
                if(self.multiIndex[0]==35):
                    self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[2]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[3]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[4]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[5]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                else:
                    self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    
                    if(self.select_axis_index==1):
                        self.components[self.multiIndex[1]].rotate(wheelChange * 5,
                                                                      self.components[self.select_obj_index].
                                                                      axisBucket[self.select_axis_index])
                    else:
                        self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                          self.components[self.select_obj_index].
                                                                          axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[2]].rotate(wheelChange * 5,
                                                                      self.components[self.select_obj_index].
                                                                      axisBucket[self.select_axis_index])
                        
                    self.components[self.multiIndex[3]].rotate(wheelChange * 5,
                                                                          self.components[self.select_obj_index].
                                                                          axisBucket[self.select_axis_index])
                    
                    self.components[self.multiIndex[4]].rotate(wheelChange * 5,
                                                                      self.components[self.select_obj_index].
                                                                      axisBucket[self.select_axis_index])
                    if(self.select_axis_index==2):
                        self.components[self.multiIndex[5]].rotate(-wheelChange * 5,
                                                                          self.components[self.select_obj_index].
                                                                          axisBucket[self.select_axis_index])
                    else:
                         self.components[self.multiIndex[5]].rotate(wheelChange * 5,
                                                                          self.components[self.select_obj_index].
                                                                          axisBucket[self.select_axis_index])
                    
            elif(len(self.multiIndex)==8):
                self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                self.components[self.multiIndex[2]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                self.components[self.multiIndex[3]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                self.components[self.multiIndex[4]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                self.components[self.multiIndex[5]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                self.components[self.multiIndex[6]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                self.components[self.multiIndex[7]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
            elif(len(self.multiIndex)==26):
                self.components[self.multiIndex[0]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[1]].rotate(-wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[2]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                
                if(self.select_axis_index==0):
                    self.components[self.multiIndex[3]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                else:
                    self.components[self.multiIndex[3]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                self.components[self.multiIndex[4]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                if(self.select_axis_index==0):
                    self.components[self.multiIndex[5]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                else:
                    self.components[self.multiIndex[5]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                #left upper fingers
                if(self.select_axis_index==1):
                    self.components[self.multiIndex[6]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[7]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[8]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[9]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[10]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                else:
                    self.components[self.multiIndex[6]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[7]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[8]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[9]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[10]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                #right upper fingers
                self.components[self.multiIndex[11]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[12]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[13]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[14]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[15]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                #left lower fingers
                if(self.select_axis_index==1):
                    self.components[self.multiIndex[16]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[17]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[18]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[19]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[20]].rotate(-wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                else:
                    self.components[self.multiIndex[16]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[17]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[18]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[19]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                    self.components[self.multiIndex[20]].rotate(wheelChange * 5,
                                                                  self.components[self.select_obj_index].
                                                                  axisBucket[self.select_axis_index])
                #right lower fingers
                self.components[self.multiIndex[21]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[22]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[23]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[24]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                self.components[self.multiIndex[25]].rotate(wheelChange * 5,
                                                              self.components[self.select_obj_index].
                                                              axisBucket[self.select_axis_index])
                
        self.update()

    def Interrupt_MouseL(self, x, y):
        """
        When mouse click detected, store current position in last_mouse_leftPosition

        :param x: Mouse click's x coordinate
        :type x: int
        :param y: Mouse click's y coordinate
        :type y: int
        :return: None
        """
        self.last_mouse_leftPosition[0] = x
        self.last_mouse_leftPosition[1] = y
        #print(x,y)
        
    def Interrupt_MouseLeftDragging(self, x, y):
        """
        When mouse drag motion detected, interrupt with new mouse position

        :param x: Mouse drag new position's x coordinate
        :type x: int
        :param y: Mouse drag new position's x coordinate
        :type y: int
        :return: None
        """
        # Change viewing angle when dragging happened
        dx = x - self.last_mouse_leftPosition[0]
        dy = y - self.last_mouse_leftPosition[1]
        mag = math.sqrt(dx * dx + dy * dy)
        axis = (dy / mag, -dx / mag, 0) if mag != 0 else (1, 0, 0)
        viewing_delta = 3.14159265358 / 180
        s = math.sin(0.5 * viewing_delta)
        c = math.cos(0.5 * viewing_delta)
        q = Quaternion(c, s * axis[0], s * axis[1], s * axis[2])
        self.viewing_quaternion = q.multiply(self.viewing_quaternion)
        self.viewing_quaternion.normalize()  # to correct round-off error caused by cos/sin
        self.last_mouse_leftPosition[0] = x
        self.last_mouse_leftPosition[1] = y

    def update(self):
        """
        Update current canvas
        :return: None
        """
        self.modelUpdate()

    def Interrupt_MouseMoving(self, x, y):
        ##### BONUS 2 (TODO 6 for CS680 student): Finishing touch - eyes!
        # Requirements:
        #   1. Add eyes to the creature model, for each it consists of an eyeball and pupil.
        #   2. Make eyes automatically follow the mouse position by rotating the eyeball.
        #   3. (extra credits) Use quaternion to implement the eyeball rotation
        
        #right 445 497
        #left 411 494
        x1 = 445
        x2 = 411
        y1 = 497
        y2 = 494
        
        top1 = x1*x + y1*y
        bottom1 = math.sqrt(x1**2+y1**2) * math.sqrt(x**2+y**2)
        cosTheta1 = top1/bottom1
        
        top2 = x2*x + y2*y
        bottom2 = math.sqrt(x2**2+y2**2) * math.sqrt(x**2+y**2)
        cosTheta2 = top2/bottom2
        
        deg1 = math.acos(cosTheta1)*360
        deg2 = math.acos(cosTheta2)*360
        
        deg3 = math.asin( math.sqrt( (1-(cosTheta1)**2) ) )*360
        deg4 = math.asin( math.sqrt( (1-(cosTheta2)**2) ) )*360
        
        if(deg1>40):
            deg1 = 40
        if(deg1<-15):
            deg1 = -15
        if(deg2>40):
            deg2 = 40
        if(deg2<-15):
            deg2 = -15
            
        if(deg4>40):
            deg4 = 40
        if(deg4<-15):
            deg4 = -15
        if(deg3>40):
            deg3 = 40
        if(deg3<-40):
            deg3 = -40
            
        if(y1>y):
            deg1 = -deg1
            deg2 = -deg2
        if(y1==y):
            deg1 = 0
        if(y2==y):
            deg2 = 0
        if(x1>x):
            deg3 = -deg3
        if(x2>x):
            deg4 = -deg4
        self.components[1].setDefaultAngle(deg1,[0,1,0])
        self.components[1].setDefaultAngle(deg3,[0,0,1])
        self.components[2].setDefaultAngle(deg2,[0,1,0])
        self.components[2].setDefaultAngle(deg4,[0,0,1])
        self.update()
        pass

    def Interrupt_Keyboard(self, keycode):
        """
        Keyboard interrupt bindings

        :param keycode: wxpython keyboard event's keycode
        :return: None
        """
        ##### TODO 5: Define creature poses and set interface to iterate through them
        # Requirements:
        #   1. Set 5 different poses of the creature.
        #   2. Add a keyboard interface "T" to cycle through the poses.
        #   3. Add multi-select feature to the interface, so you can change multiple joints at the same time. 

        if keycode in [wx.WXK_RETURN]:
            # enter component editing mode
            self.multi=False
            if len(self.components) > self.select_obj_index >= 0:
                self.components[self.select_obj_index].reset("color")

            self.select_axis_index = 0
            if len(self.components) > 0:
                if self.select_obj_index < 0:
                    self.select_obj_index = 0
                else:
                    self.select_obj_index = (self.select_obj_index + 1) % len(self.components)

            if len(self.components) > self.select_obj_index >= 0:
                self.components[self.select_obj_index].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode in [wx.WXK_LEFT]:
            # Last rotation axis of this component
            self.select_axis_index = (self.select_axis_index - 1) % 3
            if self.multi == False and len(self.components) > self.select_obj_index >= 0:
                self.components[self.select_obj_index].setCurrentColor(self.select_color[self.select_axis_index])
            else:
                if(len(self.multiIndex)==2):
                    self.components[self.multiIndex[0]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[1]].setCurrentColor(self.select_color[self.select_axis_index])
                if(len(self.multiIndex)==4):
                    self.components[self.multiIndex[0]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[1]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[2]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[3]].setCurrentColor(self.select_color[self.select_axis_index])
                if(len(self.multiIndex)==6):
                    self.components[self.multiIndex[0]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[1]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[2]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[3]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[4]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[5]].setCurrentColor(self.select_color[self.select_axis_index])
                if(len(self.multiIndex)==8):
                    self.components[self.multiIndex[0]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[1]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[2]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[3]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[4]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[5]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[6]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[7]].setCurrentColor(self.select_color[self.select_axis_index])
                if(len(self.multiIndex)==26):
                    self.components[3].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[4].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[5].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[6].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[7].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[8].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[9].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[10].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[11].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[12].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[13].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[14].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[15].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[16].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[17].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[18].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[19].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[20].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[21].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[22].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[23].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[24].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[25].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[26].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[27].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[28].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
            
        if keycode == 49:
            self.colorReset()
            self.multi = True
            self.multiIndex = [3,4]
            self.components[3].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[4].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 50:
            self.colorReset()
            self.multi = True
            self.multiIndex = [3,4,5,6]
            self.components[3].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[4].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[5].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[6].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 51:
            self.colorReset()
            self.multi = True
            self.multiIndex = [3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,
                               21,22,23,24,25,26,27,28]
            self.components[3].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[4].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[5].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[6].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[7].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[8].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[9].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[10].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[11].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[12].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[13].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[14].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[15].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[16].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[17].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[18].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[19].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[20].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[21].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[22].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[23].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[24].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[25].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[26].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[27].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[28].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 52:
            self.colorReset()
            self.multi = True
            self.multiIndex = [29,30]
            self.components[29].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[30].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 53:
            self.colorReset()
            self.multi = True
            self.multiIndex = [29,30,31,32]
            self.components[29].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[30].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[31].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[32].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 54:
            self.colorReset()
            self.multi = True
            self.multiIndex = [29,30,31,32,33,34]
            self.components[29].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[30].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[31].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[32].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[33].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[34].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 55:
            self.colorReset()
            self.multi = True
            self.multiIndex = [35,36]
            self.components[35].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[36].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 56:
            self.colorReset()
            self.multi = True
            self.multiIndex = [35,36,37,38]
            self.components[35].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[36].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[37].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[38].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 57:
            self.colorReset()
            self.multi = True
            self.multiIndex = [35,36,37,38,39,40]
            self.components[35].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[36].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[37].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[38].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[39].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[40].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode == 48:
            self.colorReset()
            self.multi = True
            self.multiIndex = [35,36,37,38,39,40,41,42]
            self.components[35].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[36].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[37].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[38].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[39].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[40].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[41].setCurrentColor(self.select_color[self.select_axis_index])
            self.components[42].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode in [wx.WXK_RIGHT]:
            
            # Next rotation axis of this component
            self.select_axis_index = (self.select_axis_index + 1) % 3
            if self.multi == False and len(self.components) > self.select_obj_index >= 0:
                self.components[self.select_obj_index].setCurrentColor(self.select_color[self.select_axis_index])
            else:
                if(len(self.multiIndex)==2):
                    self.components[self.multiIndex[0]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[1]].setCurrentColor(self.select_color[self.select_axis_index])
                if(len(self.multiIndex)==4):
                    self.components[self.multiIndex[0]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[1]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[2]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[3]].setCurrentColor(self.select_color[self.select_axis_index])
                if(len(self.multiIndex)==6):
                    self.components[self.multiIndex[0]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[1]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[2]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[3]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[4]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[5]].setCurrentColor(self.select_color[self.select_axis_index])
                if(len(self.multiIndex)==8):
                    self.components[self.multiIndex[0]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[1]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[2]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[3]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[4]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[5]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[6]].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[self.multiIndex[7]].setCurrentColor(self.select_color[self.select_axis_index])
                if(len(self.multiIndex)==26):
                    self.components[3].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[4].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[5].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[6].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[7].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[8].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[9].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[10].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[11].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[12].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[13].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[14].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[15].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[16].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[17].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[18].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[19].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[20].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[21].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[22].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[23].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[24].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[25].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[26].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[27].setCurrentColor(self.select_color[self.select_axis_index])
                    self.components[28].setCurrentColor(self.select_color[self.select_axis_index])
            self.update()
        if keycode in [wx.WXK_UP]:
            # Increase rotation angle
            self.Interrupt_Scroll(1)
            self.update()
        if keycode in [wx.WXK_DOWN]:
            # Decrease rotation angle
            self.Interrupt_Scroll(-1)
            self.update()
        if keycode in [wx.WXK_ESCAPE]:
            # exit component editing mode
            if len(self.components) > self.select_obj_index >= 0:
                self.components[self.select_obj_index].reset("color")
            self.select_obj_index = -1
            self.select_axis_index = -1
            self.update()
        if chr(keycode) in "r":
            # reset viewing angle only
            self.viewing_quaternion = Quaternion()
        if chr(keycode) in "R":
            # reset everything
            for c in self.components:
                c.reset()
            self.viewing_quaternion = Quaternion()
            self.select_obj_index = 0
            self.select_axis_index = 0
            self.update()
        if chr(keycode) in "t":
            self.topLevelComponent.children = []
            if len(self.test_case_list) != 0:
                self.test_case_index = (self.test_case_index + 1) % len(self.test_case_list)
            print("test case ",self.test_case_index)
            self.test_case_list[self.test_case_index]()
            self.update()
            
    def test0(self):
        neckAngle=-90
        ShoulderAngle=0
        ElbowAngle=0
        WristAngle=-0
        UpperFingerAngle=0
        LowerFingerAngle=0
        ButtAngle=0
        KneeAngle=0
        FootAngle=270
        wingAngle=10
        creature = Angel(self, Point((0, 0, 0)),None,neckAngle,ShoulderAngle, ElbowAngle,WristAngle,UpperFingerAngle,LowerFingerAngle,ButtAngle,KneeAngle,FootAngle,wingAngle)
        
        self.topLevelComponent.addChild(creature)
    def test1(self):
        neckAngle=-90
        ShoulderAngle=30
        ElbowAngle=10
        WristAngle=-50
        UpperFingerAngle=0
        LowerFingerAngle=0
        ButtAngle=50
        KneeAngle=50
        FootAngle=270
        wingAngle=20
        creature = Angel(self, Point((0, 0, 0)),None,neckAngle,ShoulderAngle, ElbowAngle,WristAngle,UpperFingerAngle,LowerFingerAngle,ButtAngle,KneeAngle,FootAngle,wingAngle)
        
        self.topLevelComponent.addChild(creature)
    def test2(self):
        neckAngle=-70
        ShoulderAngle=-60
        ElbowAngle=-30
        WristAngle=0
        UpperFingerAngle=-30
        LowerFingerAngle=-30
        ButtAngle=-90
        KneeAngle=30
        FootAngle=290
        wingAngle=30
        creature = Angel(self, Point((0, 0, 0)),None,neckAngle,ShoulderAngle, ElbowAngle,WristAngle,UpperFingerAngle,LowerFingerAngle,ButtAngle,KneeAngle,FootAngle,wingAngle)
        
        self.topLevelComponent.addChild(creature)
    def test3(self):
        neckAngle=-100
        ShoulderAngle=-30
        ElbowAngle=-50
        WristAngle=20
        UpperFingerAngle=-50
        LowerFingerAngle=-50
        ButtAngle=30
        KneeAngle=90
        FootAngle=270
        wingAngle=40
        creature = Angel(self, Point((0, 0, 0)),None,neckAngle,ShoulderAngle, ElbowAngle,WristAngle,UpperFingerAngle,LowerFingerAngle,ButtAngle,KneeAngle,FootAngle,wingAngle)
        
        self.topLevelComponent.addChild(creature)
        
    def test4(self):
        neckAngle=-90
        ShoulderAngle=-90
        ElbowAngle=-90
        WristAngle=-30
        UpperFingerAngle=-10
        LowerFingerAngle=-10
        ButtAngle=0
        KneeAngle=0
        FootAngle=270
        wingAngle=50
        creature = Angel(self, Point((0, 0, 0)),None,neckAngle,ShoulderAngle, ElbowAngle,WristAngle,UpperFingerAngle,LowerFingerAngle,ButtAngle,KneeAngle,FootAngle,wingAngle)
        
        self.topLevelComponent.addChild(creature)
        
    def test5(self):
        neckAngle=-60
        ShoulderAngle=-45
        ElbowAngle=-120
        WristAngle=-70
        UpperFingerAngle=-90
        LowerFingerAngle=-100
        ButtAngle=30
        KneeAngle=-30
        FootAngle=270
        wingAngle=60
        creature = Angel(self, Point((0, 0, 0)),None,neckAngle,ShoulderAngle, ElbowAngle,WristAngle,UpperFingerAngle,LowerFingerAngle,ButtAngle,KneeAngle,FootAngle,wingAngle)
        
        self.topLevelComponent.addChild(creature)
if __name__ == "__main__":
    print("This is the main entry! ")
    app = wx.App(False)
    # Set FULL_REPAINT_ON_RESIZE will repaint everything when scaling the frame, here is the style setting for it: wx.DEFAULT_FRAME_STYLE | wx.FULL_REPAINT_ON_RESIZE
    # Resize disabled in this one
    frame = wx.Frame(None, size=(800, 800), title="Test",
                     style=wx.DEFAULT_FRAME_STYLE | wx.FULL_REPAINT_ON_RESIZE)  # Disable Resize: ^ wx.RESIZE_BORDER
    canvas = Sketch(frame)

    frame.Show()
    app.MainLoop()
